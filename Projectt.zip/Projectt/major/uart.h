#include "headers.h"              // Include project-specific header file that contains required declarations

// ---------------- UART0 Function Prototypes ----------------
void Init_UART0(void);            // Initialize UART0 with required settings (baud rate, parity, stop bits, etc.)
void U0_TxByte(u8 );              // Transmit a single byte via UART0
u8   U0_RxByte(void);             // Receive a single byte from UART0
void U0_TxStr(s8 *);              // Transmit a null-terminated string via UART0
void U0_TxU32(u32 );              // Transmit a 32-bit unsigned integer via UART0
void U0_TxS32(s32 );              // Transmit a 32-bit signed integer via UART0
void U0_TxF32(f32 ,u32 );         // Transmit a floating-point number with given precision via UART0
s8*  U0_RxStr(void);              // Receive a string from UART0 (until termination character)
void U0_TxHex(u32 );              // Transmit a number in hexadecimal format via UART0
void UART0_ISR(void) __irq;       // UART0 Interrupt Service Routine (ISR) definition

// ---------------- UART1 Function Prototypes ----------------
void Init_UART1(void);            // Initialize UART1 with required settings
void U1_TxByte(u8 );              // Transmit a single byte via UART1
u8   U1_RxByte(void);             // Receive a single byte from UART1
void U1_TxStr(s8 *);              // Transmit a null-terminated string via UART1
void U1_TxU32(u32 );              // Transmit a 32-bit unsigned integer via UART1
void U1_TxS32(s32 );              // Transmit a 32-bit signed integer via UART1
void U1_TxF32(f32 ,u32 );         // Transmit a floating-point number with given precision via UART1
s8*  U1_RxStr(void);              // Receive a string from UART1 (until termination character)
void U1_TxHex(u32 );              // Transmit a number in hexadecimal format via UART1
void UART1_ISR(void) __irq;       // UART1 Interrupt Service Routine (ISR) definition
