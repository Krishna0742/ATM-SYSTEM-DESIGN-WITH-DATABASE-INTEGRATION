#include <LPC21xx.h>          // Header file for LPC21xx microcontroller register definitions
#include <string.h>           // Standard C library for string handling

//types.h
typedef unsigned char u8;     // Define u8 as unsigned 8-bit integer
typedef signed char s8;       // Define s8 as signed 8-bit integer
typedef unsigned int u32;     // Define u32 as unsigned 32-bit integer
typedef signed int s32;       // Define s32 as signed 32-bit integer
typedef float f32;            // Define f32 as float (32-bit floating point)

//LCD DEFINES
#define CLEAR_LCD 0x01        // LCD command: Clear display
#define SET_CUR_RIGHT 0x06    // LCD command: Cursor move right
#define DISP_OFF 0x08         // LCD command: Display OFF
#define DISP_ON_CUR_OFF 0x0C  // LCD command: Display ON, Cursor OFF
#define DISP_ON_CUR_ON  0x0E  // LCD command: Display ON, Cursor ON
#define DISP_ON_CUR_BLK 0x0F  // LCD command: Display ON, Cursor Blinking
#define MODE_8BIT_1LINE 0x30  // LCD mode: 8-bit, 1 line
#define MODE_4BIT_1LINE 0x20  // LCD mode: 4-bit, 1 line
#define MODE_8BIT_2LINE 0x38  // LCD mode: 8-bit, 2 lines
#define MODE_4BIT_2LINE 0x28  // LCD mode: 4-bit, 2 lines
#define GOTO_LINE1_POS0 0x80  // LCD command: Move cursor to line1 position 0
#define GOTO_LINE2_POS0 0xC0  // LCD command: Move cursor to line2 position 0
#define LCD_DATA 0            // Starting bit position of LCD data pins
#define RS_PIN 8              // Register Select pin for LCD (P0.8)
#define RW_PIN 9              // Read/Write pin for LCD (P0.9)
#define EN_PIN 10             // Enable pin for LCD (P0.10)

//4X4 KEYPAD DEFINES
#define ROW0 16               // Keypad row0 connected to P1.16
#define ROW1 17               // Keypad row1 connected to P1.17
#define ROW2 18               // Keypad row2 connected to P1.18
#define ROW3 19               // Keypad row3 connected to P1.19
#define COL0 20               // Keypad column0 connected to P1.20
#define COL1 21               // Keypad column1 connected to P1.21
#define COL2 22               // Keypad column2 connected to P1.22
#define COL3 23               // Keypad column3 connected to P1.23

//RTC DEFINES
#define FOSC 12000000         // Oscillator frequency = 12 MHz
#define CCLK (FOSC*5)         // Core clock = 60 MHz
#define PCLK (CCLK/4)         // Peripheral clock = 15 MHz
#define PREINT_VAL (int)((PCLK/32768)-1)    // RTC prescaler integer part
#define PREFRAC_VAL (PCLK-((PREINT+1)*32768)) // RTC prescaler fractional part
#define RTC_EN 0              // RTC enable bit
#define RTC_RESET 1           // RTC reset bit
#define RTC_CLKSRC 4          // RTC clock source bit

#define LED 18                // LED connected to P0.18
#define ADC 19                // ADC pin (or device) connected to P0.19

//LCD DECLARATIONS
void Init_LCD(void);          // Function to initialize LCD
void Write_LCD(u8);           // Function to write data to LCD
void CmdLCD(u8);              // Function to send command to LCD
void CharLCD(u8);             // Function to display a character
void StrLCD(u8*);             // Function to display a string
void U32LCD(u32);             // Function to display unsigned integer

//KEYPAD DECLARATIONS
void Init_KPM(void);          // Function to initialize keypad
u32 ColScan(void);            // Function to scan columns of keypad
u32 RowCheck(void);           // Function to check active row
u32 ColCheck(void);           // Function to check active column
u8  Read_key(void);           // Function to read a single key
u8* Read_String(u32);         // Function to read a string from keypad

//DELAY DECLARATIONS 
void dealy_s(u32);            // Delay in seconds (typo: should be delay_s)
void delay_ms(u32);           // Delay in milliseconds
void delay_us(u32);           // Delay in microseconds

//RTC DECLARATIONS
void RTC_Init(void);          // Initialize RTC
void Display_RTC_Time(void);  // Display current time on LCD
void Set_RTC_Time(u32,u32,u32); // Set RTC time (hour, min, sec)
void Display_RTC_Date(void);  // Display current date on LCD
void Set_RTC_Date(u32,u32,u32); // Set RTC date (year, month, day)
void Display_RTC_Day(void);   // Display day of the week
void Set_RTC_Day(u32 );       // Set day of the week

//EINT0 EINT1 DECLARATIONS
void EXTINT_Init(void);       // Initialize external interrupts
void EXTINT0_ISR(void)__irq;  // ISR for External Interrupt 0
void EXTINT1_ISR(void)__irq;  // ISR for External Interrupt 1

//CHECKING FUNCTIONS
void Check_Time(void);        // Function to check schedule time
void Edit_RTC(void);          // Function to edit RTC values
void Edit_Schedule_Time(void);// Function to edit schedule times
u32 Read_num(void);           // Function to read numeric value from keypad
u8 Validate(u32,u8 *[]);      // Function to validate user choice
void New_Password(void);      // Function to set new password

// MENU DEFINITIONS
u8 *MENU[]={"1:EDIT RTC","2:EDIT SCHEDULE","3:EDIT PASSWORD","4:EXIT"};  // Main menu options
u8 *SCHEDULE[]={"1:STARTING TIME","2:ENDING TIME","3:EXIT"};             // Schedule menu options
u8 *SCHEDULEHM[]={"1:EDIT HOUR","2:EDIT MIN","3:EXIT"};                  // Schedule Hour/Minute menu
u8 *RTC[]={"1:CHANGE HOUR","2:CHANGE MIN","3:CHANGE SEC","4:CHANGE DAY","5:CHANGE YEAR","6:CHANGE MONTH","7:CHANGE DATE","8:EXIT"}; // RTC edit menu
u8 week_day[][4]={"SUN","MON","TUE","WED","THU","FRI","SAT"};            // Days of the week
u8 KPMLUT[][4]={'7','8','9','*','4','5','6','/','1','2','3','-','c','0','=','+'}; // Keypad lookup table
u8 password[10]="1234",*givenpassword;  // Default password = "1234"
s32 chances,flag1=0,shs=9,ehe=18,sms=30,eme=30; // Variables: chances, flag, schedule start/end hour/min

//main
main()
{
	IODIR0|=(1<<LED)|(1<<ADC);       // Configure LED and ADC pins as output
	IOCLR0=1<<LED;                   // Initially turn OFF LED
	Init_LCD();                      // Initialize LCD
	Init_KPM();                      // Initialize Keypad
	RTC_Init();                      // Initialize RTC
	Set_RTC_Time(10,40,00);          // Set RTC time to 10:40:00
	Set_RTC_Date(2024,4,1);          // Set RTC date to 1st April 2024
	Set_RTC_Day(3);                  // Set RTC day (3 = Wednesday)
	EXTINT_Init();                   // Initialize external interrupts
	while(1)                         // Infinite loop
	{
		Display_RTC_Time();          // Continuously display RTC time
		Display_RTC_Day();           // Continuously display RTC day
		Display_RTC_Date();          // Continuously display RTC date
	}
}
