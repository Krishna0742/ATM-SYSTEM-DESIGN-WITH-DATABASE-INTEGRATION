#include "headers.h"

// Initialize UART0
void Init_UART0(void)
{
	PINSEL0 = ((PINSEL0 & ~(3<<(2*0))) | (1<<(2*0))); // Configure P0.0 as TXD0
	PINSEL0 = ((PINSEL0 & ~(3<<(2*1))) | (1<<(2*1))); // Configure P0.1 as RXD0
	U0LCR = ((1<<DLAB_BIT) | (WORD_LEN_SEL_BITS));    // Set word length, enable DLAB to set divisor
	U0DLL = (DIVISOR);                               // Set divisor low byte
	U0DLM = (DIVISOR >> 8);                          // Set divisor high byte
	U0LCR &= ~(1<<DLAB_BIT);                         // Clear DLAB after setting divisor
	U0IER = 0x01;                                    // Enable UART0 receive data available interrupt
	VICIntSelect = 0x00000000;                       // Set VIC for IRQ (not FIQ)
	VICIntEnable |= (1 << 6);                        // Enable VIC interrupt for UART0 (slot 6)
	VICVectAddr0 = (unsigned int)UART0_ISR;         // Set ISR address for UART0
	VICVectCntl0 = 0x20 | 6;                         // Enable VIC slot 0, assign UART0
}

// Transmit a single byte via UART0
void U0_TxByte(u8 sByte)
{
	U0THR = sByte;                                    // Write byte to transmit holding register
	while (((U0LSR >> TEMT_BIT) & 1) == 0);          // Wait until transmitter is empty
}

// Receive a single byte via UART0
u8 U0_RxByte(void)
{
	while (((U0LSR >> DR_BIT) & 1) == 0);            // Wait until data is available
	return U0RBR;                                    // Read received byte
}

// Transmit a string via UART0
void U0_TxStr(s8 *str)
{
	while (*str)                                     // Loop until string end
		U0_TxByte(*str++);                           // Send each character
}

// Receive a string from UART0 until '$'
s8* U0_RxStr(void)
{
	static s8 buffer[100];                           // Static buffer to store string
	u32 i = 0;
	while (1)
	{
		buffer[i] = U0_RxByte();                     // Receive a byte
		if (buffer[i] == '$')                        // Stop if '$' received
			break;
		i++;
	}
	buffer[i+1] = '\0';                              // Null-terminate string
	return buffer;                                   // Return pointer to buffer
}

// Initialize UART1
void Init_UART1(void)
{
	PINSEL0 = ((PINSEL0 & ~(3<<(2*8))) | (1<<(2*8))); // Configure P0.8 as TXD1
	PINSEL0 = ((PINSEL0 & ~(3<<(2*9))) | (1<<(2*9))); // Configure P0.9 as RXD1
	U1LCR = ((1<<DLAB_BIT) | (WORD_LEN_SEL_BITS));    // Set word length, enable DLAB
	U1DLL = (DIVISOR);                               // Set divisor low byte
	U1DLM = (DIVISOR >> 8);                          // Set divisor high byte
	U1LCR &= ~(1<<DLAB_BIT);                         // Clear DLAB
	U1IER = 0x01;                                    // Enable UART1 receive interrupt
	VICIntSelect = 0x00000000;                       // IRQ mode
	VICIntEnable |= (1 << 7);                        // Enable UART1 interrupt in VIC
	VICVectAddr1 = (unsigned int)UART1_ISR;         // Set ISR address
	VICVectCntl1 = 0x20 | 7;                         // Enable VIC slot 1, assign UART1
}

// Transmit a single byte via UART1
void U1_TxByte(u8 sByte)
{
	U1THR = sByte;                                   // Write byte to UART1 THR
	while (((U1LSR >> TEMT_BIT) & 1) == 0);         // Wait until transmitter empty
}

// Receive a single byte via UART1
u8 U1_RxByte(void)
{
	while (((U1LSR >> DR_BIT) & 1) == 0);           // Wait for data ready
	return U1RBR;                                   // Return received byte
}

// Transmit a string via UART1
void U1_TxStr(s8 *str)
{
	while (*str)                                    // Loop through string
		U1_TxByte(*str++);                          // Send each character
}

// Receive a string from UART1 until '$'
s8* U1_RxStr(void)
{
	static s8 buffer[100];                          // Static buffer
	u32 i = 0;
	while (1)
	{
		buffer[i] = U1_RxByte();                    // Receive byte
		if (buffer[i] == '$')                       // Stop if '$'
			break;
		i++;
	}
	buffer[i+1] = '\0';                             // Null-terminate
	return buffer;                                  // Return pointer
}

// UART1 interrupt service routine
void UART1_ISR(void)__irq
{
	u8 ch;
	u32 iirval = U1IIR;                              // Read interrupt identification register
	IOSET0 = 1<<LED;                                 // Turn on LED to indicate ISR

	if ((iirval & 0x0F) == 0x04)                     // Check if RDA (Receive Data Available)
	{
		ch = U1RBR;                                  // Read received byte
		if (!uart1_rx_complete)
		{
			if (!uart1_rx_started)
			{
				if (ch == 0x02)                     // Start-of-text character (STX)
				{
					uart1_rx_index = 0;             // Reset index
					uart1_rx_started = 1;           // Mark start of reception
				}
			}
			else
			{
				if (ch == 0x03)                     // End-of-text character (ETX)
				{
					uart1_rx_buf[uart1_rx_index] = '\0'; // Null terminate
					uart1_rx_complete = 1;          // Mark reception complete
					uart1_rx_started = 0;           // Reset flag
					uart1_rx_index = 0;             // Reset index
				}
				else if ((uart1_rx_index < MAX_BUF_LEN1-1) && ((ch >= 48) && (ch <= 57))) // Only numeric
				{
					uart1_rx_buf[uart1_rx_index++] = ch; // Store digit
				}
			}
		}
	}
	IOCLR0 = 1<<LED;                                 // Turn off LED
	VICVectAddr = 0x00;                              // Clear VIC vector address
}

// UART0 interrupt service routine
void UART0_ISR(void) __irq
{
	char ch;
	static int receiving = 0;                         // Track if reception started
	u32 iirval = U0IIR;                               // Read UART0 IIR

	if ((iirval & 0x0F) == 0x04)                     // Check if RDA
	{
		ch = U0RBR;                                  // Read byte

		if (ch == '@')                               // Start marker
		{
			receiving = 1;
			uart0_rx_index = 0;                        // Reset index
			uart_checksum = 0;                         // Reset checksum
		}

		if (receiving && uart0_rx_index < MAX_BUF_LEN2 - 1)
		{
			// Accept valid characters for UART0
			if (ch == '@' || ch == '#' || ch == '$' || ch == ':' || ch == '_' || ch=='.' || ch=='|' || ch=='-' ||
			    (ch >= '0' && ch <= '9') || (ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z'))
			{
				uart0_rx_buf[uart0_rx_index++] = ch;   // Store received character
				uart_checksum += ch;                    // Update checksum
			}

			if (ch == '$')                            // End marker received
			{
				uart0_rx_buf[uart0_rx_index] = '\0';  // Null-terminate
				receiving = 0;                         // End reception

				if (uart_checksum > 0 && uart0_rx_index > 1) // Valid data
				{
					uart0_rx_complete = 1;            // Mark complete
					uart0_rx_valid = 1;               // Mark valid
				}
				else
				{
					uart0_rx_complete = 0;            // Invalid reception
					uart0_rx_valid = 0;
				}

				uart0_rx_index = 0;                     // Reset index
			}
		}
	}

	if (receiving && uart0_rx_index > 0 && uart0_rx_buf[uart0_rx_index - 1] != '$') // If not ended properly
	{
		uart0_rx_valid = 0;                           // Mark invalid
		uart0_rx_complete = 0;                        // Ensure retry
	}

	VICVectAddr = 0x00;                              // Clear VIC vector
}

