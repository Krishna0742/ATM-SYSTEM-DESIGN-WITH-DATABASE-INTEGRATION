#include "headers.h"   // Include all necessary header files

// Function to read a string from keypad input
s8* Read_String() {
    static s8 arr[50];   // Buffer to hold input string
    u8 c;                // Variable to store a key press
    s32 i = 0;           // Index for buffer
    
    // Initialize buffer with null characters
    for (i = 49; i >= 0; i--) 
        arr[i] = '\0';

    i = 0;
    while (1) {
        c = Read_key();  // Read a key press
        
        if (c == TIMEOUT_FLAG)
        {  
            return NULL; // Return NULL if timeout occurs
        }

        if (c == '=')  // Check if input ends
        {
            arr[i] = '\0';  // Null terminate string
            break;          // Exit input loop
        } 
        else if (c == 'c')  // Backspace functionality
        {
            i--;                            // Move back index
            CmdLCD(GOTO_LINE2_POS0 + i);    // Move cursor on LCD
            CharLCD(' ');                    // Erase character on LCD
            arr[i] = '\0';                   // Remove from buffer
            if (i <= 0)
                i = 0;                       // Prevent negative index
        }
        else if ((c >= '0') && (c <= '9')) // Accept only numeric input
        {
            arr[i] = c;                       // Store character
            CmdLCD(GOTO_LINE2_POS0 + i);      // Move cursor
            CharLCD(c);                        // Display digit
            delay_ms(50);                      // Delay for debounce
            CmdLCD(GOTO_LINE2_POS0 + i);      // Position cursor again
            CharLCD(c);                        // Display digit again
            i++;                               // Increment index
        }

        while ((ColScan() & 1) == 0);          // Wait until key released
        delay_ms(100);                         // Small delay
    }
    return arr;                                // Return input string
}

// Function to read a 4-digit PIN from keypad
s8* Read_PIN(u32 flag) {
    static s8 arry[5];      // Buffer for PIN
    u8 c;                   // Store key press
    s32 i = 0;              // Index

    // Initialize buffer with null characters
    for (i = 4; i >= 0; i--) 
        arry[i] = '\0';

    i = 0;
    while (i < 4) {         // Loop for 4-digit PIN
        c = Read_key();     // Read key press

        if (c == TIMEOUT_FLAG) {  
            return NULL;    // Exit if timeout occurs
        }

        if (c == 'c')  // Backspace
        {
            i--;  
            CmdLCD(GOTO_LINE2_POS0 + i);  
            CharLCD(' ');  
            arry[i] = '\0';  
            if (i <= 0)  
                i = 0;  
        } 
        else if ((c >= '0') && (c <= '9')) // Numeric input
        {
            arry[i] = c;  
            CmdLCD(GOTO_LINE2_POS0 + i);  
            CharLCD(c);  
            delay_ms(100);  
            CmdLCD(GOTO_LINE2_POS0 + i);  
            if(flag)  
                CharLCD('*');  // Mask input if flag is set
            else  
                CharLCD(c);  
            i++;  
        }

        while ((ColScan() & 1) == 0); // Wait for key release
        delay_ms(100);  
    }
    
    arry[i] = '\0';  
    return arry;  // Return entered PIN
}

// Function to validate PIN against backend
u32 validate_PIN(void)
{
    s8 buffer[30], reference_pin[10];  // Buffers for communication
    
    for(chances=3; chances>0; chances--)  // Allow 3 attempts
    {
        CmdLCD(CLEAR_LCD);  
        CmdLCD(GOTO_LINE1_POS0);  
        StrLCD((s8 *)"ENTER PIN:");  // Prompt for PIN
        givenpin = Read_PIN(1);     // Read masked PIN
        if(givenpin == NULL)  // Check for timeout
        { 
            CmdLCD(CLEAR_LCD);  
            CmdLCD(GOTO_LINE1_POS0);  
            StrLCD((s8*)"SESSION TIMED OUT ! ");  
            CmdLCD(GOTO_LINE2_POS0);  
            StrLCD("PLEASE TRY AGAIN ");  
            delay_s(1);  
            CmdLCD(CLEAR_LCD);  
            send_buf_to_uart0((s8*)"#TIMEOUT$");  
            return 0;  
        }
        strcpy((char *)reference_pin,(char *)givenpin);  // Copy for reference
#ifdef DEBUG
        CmdLCD(CLEAR_LCD);  
        CmdLCD(GOTO_LINE1_POS0);  
        StrLCD(reference_pin);  
#endif
        sprintf((char*)buffer,"#p%s$",givenpin);  // Prepare message to UART
#ifdef DEBUG
        CmdLCD(GOTO_LINE1_POS0);  
        StrLCD(buffer);  
        delay_ms(30);  
        send_buf_to_uart0(buffer);  
        CmdLCD(GOTO_LINE1_POS0);  
        StrLCD("ENTER UART0 BUFF");  
#endif 
        send_buf_to_uart0(buffer);  // Send PIN to backend
        recv_buf_from_uart0(buffer,sizeof(buffer));  // Receive response
        delay_s(1);  
        if(str_cmp(buffer,(s8*)"@OK$") == 0)  // Check if valid
        {  
            CmdLCD(CLEAR_LCD);  
            CmdLCD(GOTO_LINE2_POS0);  
            StrLCD((s8*)"LOGIN SUCESSFULL ");  
            delay_s(1);  
            strcpy((char *)pin,(char *)reference_pin);  // Store PIN
            flag1 = 1;  
            CmdLCD(CLEAR_LCD);  
            return 1;  
        }
        else if(str_cmp(buffer,(s8*)"@ERR#INVLD$") == 0)  // Invalid PIN
        {
            IOSET0 = 1<<LED;  
            CmdLCD(CLEAR_LCD);  
            CmdLCD(GOTO_LINE1_POS0);  
            StrLCD("INVALID PIN ");  
            if(chances==3)  
            {  
                CmdLCD(GOTO_LINE2_POS0);  
                StrLCD("YOU HAVE 2 MOVES ");  
                delay_s(1);  
            }  
            else if(chances==2)  
            {  
                CmdLCD(GOTO_LINE2_POS0);  
                StrLCD("YOU HAVE 1 MOVE ");  
                delay_s(1);  
            }  
        }
        CmdLCD(CLEAR_LCD);  
    }

    if(!flag1)  // If all attempts exhausted
    {
        IOSET0 = 1<<LED;  
        CmdLCD(CLEAR_LCD);  
        CmdLCD(GOTO_LINE1_POS0);  
        StrLCD((s8 *)"                ");  
        StrLCD("OUT OF MOVES ");  
        send_buf_to_uart0((s8*)"#BLK$");  
        recv_buf_from_uart0(buffer,sizeof(buffer));  
        if(str_cmp(buffer,(s8*)"@BLK$") == 0)  
        {  
            CmdLCD(CLEAR_LCD);  
            CmdLCD(GOTO_LINE2_POS0);  
            StrLCD("YOUR CARD BLOCKED ");  
            delay_s(1);  
            StrLCD((s8 *)"                ");  
            return 0;  
        }  
        IOCLR0 = 1<<LED;  
    }
    return 0;  
}
// Function to rotate a string on LCD (scrolling effect)
void rotate_string(const char *str,int len,u32 stop)
{
    s32 i,j,pos;             // Loop counters and position variable
    s8 buffer[16];           // Temporary buffer for 16 characters display
    while(1)                 // Infinite loop for scrolling
    {
        for(i=-16;i<len;i++) // Start scroll from -16 to length of string
        {
            for(j=0;j<16;j++)  // Fill 16-character display buffer
            {
                pos=i+j;       // Calculate position in input string
                if(pos<0||pos>=len) // Out of bounds?
                {
                    buffer[j]=' ';  // Fill with space if out of bounds
                }
                else
                {
                    buffer[j]=str[pos];  // Copy character to buffer
                }
                if(uart1_rx_complete)   // Interrupt scrolling if UART1 receives data
                {
                    break;
                }
            }
            if(uart1_rx_complete)   // Exit loop if UART1 received
            {
                CmdLCD(CLEAR_LCD);  // Clear LCD
                break;
            }
            buffer[j]='\0';  // Null terminate buffer
            CmdLCD(GOTO_LINE2_POS0);  // Go to line 2
            StrLCD(buffer);           // Display buffer
            delay_ms(200);            // Delay for scroll speed
        }
        if(uart1_rx_complete)  // Stop outer loop if UART1 received
        {
            break;
        }
        else if(stop)          // Stop if flag set
        {
            break;
        }
    }
}

// Function to display main menu and handle user selection
void main_MENU()
{
    s8 c;                     // Variable for user choice
    while(1)                  // Infinite menu loop
    {
        CmdLCD(CLEAR_LCD);  
        c=Validate(4,MENU);   // Call Validate to read user input
        CmdLCD(CLEAR_LCD);  
        if(c==NULL)           // Timeout occurred
        {
            CmdLCD(CLEAR_LCD);  
            CmdLCD(GOTO_LINE1_POS0);  
            StrLCD((s8*)"SESSION TIMED OUT ! ");  
            CmdLCD(GOTO_LINE2_POS0);  
            StrLCD("PLEASE TRY AGAIN ");  
            delay_s(1);  
            CmdLCD(CLEAR_LCD);  
            send_buf_to_uart0((s8*)"#TIMEOUT$");  
            break;  
        }
        if(c=='1')  // Balance enquiry
        {
            CmdLCD(CLEAR_LCD);  
            Bal_Enq();  
            CmdLCD(CLEAR_LCD);  
        }
        else if(c=='2')  // Deposit
        {
            CmdLCD(CLEAR_LCD);  
            if(Deposit())  // Break if deposit completed
            {
                break;  
            }
            CmdLCD(CLEAR_LCD);  
        }
        else if(c=='3')  // Withdraw
        {
            CmdLCD(CLEAR_LCD);  
            if(Withdraw())  // Break if withdrawal completed
            {
                break;  
            }
            CmdLCD(CLEAR_LCD);  
        }
        else if(c=='4')  // Change PIN
        {
            CmdLCD(CLEAR_LCD);  
            if(Pin_Change())  // Break if PIN changed
            {
                break;  
            }
            CmdLCD(CLEAR_LCD);  
        }
        else if(c=='5')  // Mini statement
        {
            CmdLCD(CLEAR_LCD);  
            Mini_Statement();  
            CmdLCD(CLEAR_LCD);  
        }
        else if(c=='6')  // Exit
        {
            CmdLCD(CLEAR_LCD);  
            CmdLCD(GOTO_LINE1_POS0);  
            StrLCD((s8 *)"   EXITED !");  
            delay_s(2);  
            CmdLCD(CLEAR_LCD);  
            send_buf_to_uart0((s8*)"#EXIT$");  
            break;  
        }
        else  // Wrong input
        {
            CmdLCD(CLEAR_LCD);  
            CmdLCD(GOTO_LINE1_POS0);  
            StrLCD((s8 *)"WRONG INPUT!");  
            delay_s(2);  
            CmdLCD(CLEAR_LCD);  
        }
    }
    CmdLCD(CLEAR_LCD);  
}

// Function to validate menu selection
s8 Validate(u32 j,s8 (*str)[16])
{
    u32 i=0;  // Menu index
    u8 c;     // Key pressed
    CmdLCD(GOTO_LINE1_POS0);  
    StrLCD(str[i]);   // Display first line of menu
    CmdLCD(GOTO_LINE2_POS0);  
    StrLCD(str[i+1]); // Display second line
    while(1)  
    {
        c=Read_key();  // Read key
        while((ColScan()&1)==0);  // Wait for key release
        if(c==TIMEOUT_FLAG)  // Timeout
        {
            return NULL;  
        }
        else if(c=='*')  // Move down menu
        {
            if(i<j)
                i++;  
            else 
                continue;  
        }
        else if(c=='/')  // Move up menu
        {
            if(i>0)
                i--;  
            else 
                continue;  
        }
        else if((c==str[i][0])||(c==str[i+1][0]))  // Selected key matches menu
        {
            break;  
        }
        CmdLCD(CLEAR_LCD);  
        CmdLCD(GOTO_LINE1_POS0);  
        StrLCD(str[i]);  
        CmdLCD(GOTO_LINE2_POS0);  
        StrLCD(str[i+1]);  
    }
    return c;  // Return selected key
}

// Receive string from UART1
void recv_str_from_uart1(s8 *str,u32 len)
{
#ifdef DEBUG
    strcpy((char*)str,"12345678");  // Use debug string
#else
    while(!uart1_rx_complete);  // Wait for reception complete
    strncpy((char*)str,(char *)uart1_rx_buf,len > MAX_BUF_LEN1 ? MAX_BUF_LEN1 : len);  // Copy data
#endif 
    uart1_rx_complete=0;  // Reset flag
}

// Receive buffer from UART0
void recv_buf_from_uart0(s8 *str,u32 len)
{	
    memset((void*)uart0_rx_buf,0,MAX_BUF_LEN2);  // Clear UART buffer
    while(!uart0_rx_complete);  // Wait for reception complete
    strncpy((char*)str,(char *)uart0_rx_buf,len);  // Copy data
    uart0_rx_complete=0;  // Reset flag
}

// Send buffer to UART0 with handshake
void send_buf_to_uart0(s8 *str)
{
    s8 buf1[14]="#OK:CNTD$",buf2[14];  // Handshake buffer
    while(1)
    {
        U0_TxStr(buf1);  // Send handshake
        recv_buf_from_uart0(buf2,14);  // Receive response
        if(str_cmp(buf2,(s8*)"@OK:CNTD$")==0)  // Response correct?
        {
            break;  // Exit loop
        }
        else
        {
            CmdLCD(CLEAR_LCD);  
            CmdLCD(GOTO_LINE1_POS0);  
            StrLCD((s8*)"WAITING FOR RESPONSE");  // Show waiting message
        }
    }
    U0_TxStr(str);  // Send actual data
}

// Compare two strings
u32 str_cmp(s8 *str1, s8 *str2) {
    while (*str1 && (*str1 == *str2))
    {
        str1++;  
        str2++;  
    }
    return (u32)(*(unsigned char *)str1 - *(unsigned char *)str2);  // Return difference
}

// Compare two strings up to n characters
u32 str_ncmp(s8 *str1, s8 *str2, u32 n) {
    while (n-- && *str1 && (*str1 == *str2)) 
    {
        str1++;  
        str2++;  
    }
    return n == (u32)-1 ? 0 : (u32)(*(unsigned char *)str1 - *(unsigned char *)str2);  
}

// Find length of string
u32 str_len(s8 *str) {
    int length = 0;  
    while (str[length] != '\0') {
        length++;  
    }
    return length;  
}

// Convert ASCII string to integer
int atoi_arm(s8 *str)
{
    int result = 0;  
    while (*str)
    {
        if (*str >= '0' && *str <= '9') 
            result = result * 10 + (*str - '0');  // Convert ASCII to integer
        else 
            return -1;  // Return -1 on invalid input
        str++;  
    }
    return result;  
}

// Function to validate RFID card
u32 validate_RFID()
{
    s8 buf1[10];  // RFID input buffer
    s8 buf2[30];  // UART communication buffer
#ifdef DEBUG
    CmdLCD(GOTO_LINE1_POS0);  
    StrLCD("ENTER UART1 BUFF");  
#endif
    recv_str_from_uart1(buf1,10);  // Receive RFID
    CmdLCD(GOTO_LINE1_POS0);  
    StrLCD((s8*)"RFID NO:");  
    CmdLCD(GOTO_LINE2_POS0);  
    StrLCD(buf1);  
    delay_s(2);  
#ifdef DEBUG
    memset((void*)uart1_rx_buf,0,MAX_BUF_LEN1);  
    recv_str_from_uart1(buf1,9);  
    CmdLCD(GOTO_LINE1_POS0);  
    StrLCD(buf1);  
#endif
    sprintf((char*)buf2,"#r%s$",buf1);  // Prepare UART message
#ifdef DEBUG
    CmdLCD(GOTO_LINE2_POS0);  
    StrLCD(buf2);  
    delay_ms(200);  
    send_buf_to_uart0(buf2);  
#endif
    send_buf_to_uart0(buf2);  
#ifdef DEBUG
    CmdLCD(GOTO_LINE1_POS0);  
    StrLCD("ENTER UART0 BUFF");  
#endif 
    recv_buf_from_uart0(buf2,30);  // Receive response
    CmdLCD(GOTO_LINE2_POS0);  
    delay_ms(200);  
#ifdef DEBUG
    CmdLCD(GOTO_LINE1_POS0);  
    StrLCD("TESTING UART0");  
    CmdLCD(GOTO_LINE2_POS0);  
    StrLCD(buf2);  
    CmdLCD(CLEAR_LCD);  
    CmdLCD(GOTO_LINE1_POS0);  
    StrLCD(buf2);  
    delay_ms(10);  
#endif
    if(str_cmp(buf2,(s8 *)"@OK#ACTV$") == 0)  // Active card
    {  
        return 1;  
    }
    else if(str_cmp(buf2,(s8*)"@BLKD$") == 0)  // Blocked card
    {
        IOSET0 = 1<<LED;  
        CmdLCD(CLEAR_LCD);  
        CmdLCD(GOTO_LINE1_POS0);  
        StrLCD((s8 *)"CARD BLOCKED !");  
        CmdLCD(GOTO_LINE2_POS0);  
        StrLCD("CONTACT MAIN BRANCH");  
        delay_s(1);  
        CmdLCD(CLEAR_LCD);  
        IOCLR0 = 1<<LED;  
    }
    else if(str_cmp(buf2,(s8*)"@ERR#CARD$") == 0)  // Invalid card
    {
        IOSET0 = 1<<LED;  
        CmdLCD(CLEAR_LCD);  
        CmdLCD(GOTO_LINE1_POS0);  
        StrLCD((s8 *)"ERROR");  
        CmdLCD(GOTO_LINE2_POS0);  
        StrLCD("INVALID CARD DETAILS ");  
        delay_s(1);  
        CmdLCD(CLEAR_LCD);  
        IOCLR0 = 1<<LED;  
    }
    return 0;  
}
