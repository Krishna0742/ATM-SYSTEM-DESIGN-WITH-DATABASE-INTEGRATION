#include "headers.h"

// Write a single byte to LCD data lines
void WriteLCD(u8 data)
{
    // Clear lower 8 bits of IOPIN1 (LCD data pins) and write new data
    IOPIN1 = ((IOPIN1 & ~(0xFF << LCD_DATA)) | (data << LCD_DATA));

    IOCLR0 = 1 << LCD_RW;  // Set LCD to write mode (RW = 0)
    IOSET0 = 1 << LCD_EN;  // Generate enable pulse
    delay_ms(1);           // Short delay to latch data
    IOCLR0 = 1 << LCD_EN;  // Clear enable pin
    delay_ms(2);           // Delay to allow LCD to process the data
}

// Send a command byte to LCD
void CmdLCD(u8 cmd)
{
    IOCLR0 = 1 << LCD_RS;  // RS = 0 for command
    WriteLCD(cmd);         // Send the command
}

// Display a single ASCII character on LCD
void CharLCD(u8 ascii)
{
    IOSET0 = 1 << LCD_RS;  // RS = 1 for data
    WriteLCD(ascii);       // Send the ASCII character
}

// Initialize LCD
void InitLCD(void)
{
    IODIR1 |= ((u32)0xFF << LCD_DATA);           // Set LCD data pins (P1.0-P1.7) as output
    IODIR0 |= (1 << LCD_RS) | (1 << LCD_RW) | (1 << LCD_EN); // Set control pins as output

    delay_ms(15);                                // Wait for LCD to power up

    CmdLCD(0x30);                                // Function set (first time)
    delay_ms(2);
    CmdLCD(0x30);                                // Function set (second time)
    delay_us(100);
    CmdLCD(0x30);                                // Function set (third time)
    
    CmdLCD(MODE_8BIT_2LINE);                     // Set 8-bit mode, 2-line display
    CmdLCD(DSP_ON_CUR_OFF);                      // Display on, cursor off
    CmdLCD(CLEAR_LCD);                           // Clear display
    CmdLCD(SHIFT_CUR_RIGHT);                     // Set entry mode: cursor moves right
}

// Display a null-terminated string on LCD
void StrLCD(s8 *str)
{
    while (*str)                                 // Loop until end of string
        CharLCD(*str++);                         // Send each character
}
