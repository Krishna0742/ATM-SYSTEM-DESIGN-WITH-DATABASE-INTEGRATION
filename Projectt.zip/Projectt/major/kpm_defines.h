#define ROW0 24   // GPIO pin 24 -> Row 0 of keypad
#define ROW1 25   // GPIO pin 25 -> Row 1 of keypad
#define ROW2 26   // GPIO pin 26 -> Row 2 of keypad
#define ROW3 27   // GPIO pin 27 -> Row 3 of keypad

#define COL0 28   // GPIO pin 28 -> Column 0 of keypad
#define COL1 29   // GPIO pin 29 -> Column 1 of keypad
#define COL2 30   // GPIO pin 30 -> Column 2 of keypad
#define COL3 31   // GPIO pin 31 -> Column 3 of keypad
