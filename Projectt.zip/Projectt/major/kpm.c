#include "headers.h"                      // Include all required project headers

u32 ColScan()                             // Function to check if any column key is pressed
{
	return (((IOPIN1>>COL0)&15)<15)?0:1;  // Shift COL0 bits, mask 4 bits, if <15 ? key pressed ? return 0, else return 1
}

u32 RowCheck()                            // Function to detect which row key is pressed
{
	u32 r;
	for(r=0;r<4;r++)                      // Loop through 4 rows
	{
		IOPIN1=((IOPIN1&~(15<<ROW0))|((~(1<<r))<<ROW0)); // Activate one row at a time (set low)
		if(ColScan()==0)                  // If a key press detected in that row
		{
			break;                        // Break and return the row index
		}
	}
	IOCLR1=15<<ROW0;                      // Clear all row lines
	return r;                             // Return detected row number
}

u32 ColCheck()                            // Function to detect which column key is pressed
{
	u32 c;
	for(c=0;c<4;c++)                      // Loop through 4 columns
	{
		if((IOPIN1>>(COL0+c)&1)==0)       // If column line is low ? key pressed
		{
			break;                        // Break and return column index
		}
	}
	return c;                             // Return detected column number
}

u8 Read_key(void)                         // Function to read a key press from keypad
{
    u32 row, col;
    s32 timeout = 10000;                  // Timeout counter (~30 seconds delay with ms decrement)
    
    while (ColScan() && timeout>0)        // Wait until a key is pressed or timeout expires
    {
        timeout--;                        // Decrement timeout each iteration
        delay_ms(1);                      // Delay 1 ms to simulate real-time timeout
    }

    if (timeout == 0)                     // If timeout expired without key press
    {
        return TIMEOUT_FLAG;              // Return special timeout flag
    }

    row = RowCheck();                     // Detect row index of pressed key
    col = ColCheck();                     // Detect column index of pressed key

    return KPMLUT[row][col];              // Return mapped key from keypad lookup table
}

void InitKPM(void)                        // Function to initialize keypad module
{
	IODIR1|=15<<ROW0;                     // Set row pins (ROW0�ROW3) as output
}
