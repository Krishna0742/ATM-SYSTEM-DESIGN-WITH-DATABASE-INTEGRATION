#include "types.h"   // Include type definitions (u8, s8, u32, f32, etc.)

void WriteLCD(u8 );          // Write raw data/command byte to LCD
void CmdLCD(u8 );            // Send command to LCD (like clear, set cursor, etc.)
void CharLCD(u8 );           // Display a single character on LCD
void InitLCD(void);          // Initialize LCD (setup function)
void StrLCD(s8 *);           // Display a string on LCD
void U32LCD(u32);            // Display an unsigned 32-bit integer on LCD
void S32LCD(s32);            // Display a signed 32-bit integer on LCD
void F32LCD(f32,u32);        // Display a float with specified precision (f32 value, u32 decimal places)
void HexLCD(u32);            // Display a number in hexadecimal format on LCD
void OctLCD(u32);            // Display a number in octal format on LCD
void BinLCD(u32,u32);        // Display a number in binary format (with length/precision control)
void BuildCGRAM(u8*,u8);     // Create custom characters in LCD�s CGRAM (Character Generator RAM)
