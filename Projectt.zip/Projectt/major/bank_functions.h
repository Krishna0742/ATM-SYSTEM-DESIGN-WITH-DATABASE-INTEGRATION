#include "headers.h"        // Include all required project headers (types, LCD, UART, etc.)

u32 Deposit(void);          // Function prototype: perform deposit transaction and return status
u32 Withdraw(void);         // Function prototype: perform withdrawal transaction and return status
u32 Pin_Change(void);       // Function prototype: allow user to change PIN and return status
void Mini_Statement(void);  // Function prototype: display/print last few transactions (mini statement)
void Bal_Enq(void);         // Function prototype: check and display balance enquiry
