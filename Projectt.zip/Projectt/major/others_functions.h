#include "headers.h"                       // Include all required headers for project functions & types

s8* Read_String(void);                      // Read a string (probably from keypad or UART)
u8  Read_key(void);                         // Read a single key press (from keypad module)
s8* Read_PIN(u32);                          // Read PIN of given length (returns pointer to string)
void Display_Wel(void);                     // Display welcome message on LCD
u32 validate_RFID(void);                    // Validate RFID card input
u32 validate_PIN(void);                     // Validate entered PIN
void recv_str_from_uart1(s8 *,u32 );        // Receive a string from UART1 into buffer (with length limit)
void recv_buf_from_uart0(s8 *,u32);         // Receive a buffer of given length from UART0
void send_buf_to_uart0(s8 *);               // Send a buffer (string) via UART0
void rotate_string(const char *,int ,u32 ); // Rotate a string by given number of positions
void main_MENU(void);                       // Display and handle main menu
s8   Validate(u32 ,s8 (*)[]);               // Validate input against a set of allowed strings (array of strings)
u32  str_cmp(s8 *,s8 *);                    // Compare two strings (like strcmp)
u32  str_ncmp(s8 *,s8 *,u32 );              // Compare two strings up to n characters (like strncmp)
u32  str_len(s8 *);                         // Return length of string (like strlen)
int  atoi_arm(s8*);                         // Convert ASCII string to integer (custom atoi implementation for ARM)
