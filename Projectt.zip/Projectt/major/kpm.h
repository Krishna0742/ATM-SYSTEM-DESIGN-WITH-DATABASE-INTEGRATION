#include "headers.h"   // Include main project header (brings in types, defines, etc.)

u32 ColScan(void);     // Scan and return active column(s) of the keypad
u32 RowCheck(void);    // Check and return active row(s) of the keypad
u32 ColCheck(void);    // Check and return active column(s) (helper function for scanning)
u8 KeyScan(void);      // Scan the entire keypad and return the pressed key value
void InitKPM(void);    // Initialize keypad module (configure GPIO pins for rows/columns)
