typedef signed char s8;          // Define s8 as a shorthand for signed 8-bit integer (-128 to 127)
typedef unsigned char u8;        // Define u8 as a shorthand for unsigned 8-bit integer (0 to 255)

typedef signed short int s16;    // Define s16 as a shorthand for signed 16-bit integer (-32768 to 32767)
typedef unsigned short int u16;  // Define u16 as a shorthand for unsigned 16-bit integer (0 to 65535)

typedef signed int s32;          // Define s32 as a shorthand for signed 32-bit integer (-2,147,483,648 to 2,147,483,647)
typedef unsigned int u32;        // Define u32 as a shorthand for unsigned 32-bit integer (0 to 4,294,967,295)

typedef float f32;               // Define f32 as a shorthand for 32-bit floating-point number
