#include "headers.h"                                      // Include all required project headers

// ---------------- Global Variables ----------------
s8 MENU[][16]={"1:BALANCE","2:DEPOSIT","3:WITHDRAW",      // Menu options displayed on LCD
               "4:PIN CHANGE","5:MINI STATEMENT","6:EXIT"};

s8 KPMLUT[][4]={'1','2','3','*',                         // Keypad Lookup Table (4x4 matrix)
                '4','5','6','/', 
                '7','8','9','-', 
                'c','0','=','+'};

s8 pin[5],*givenpin;                                     // Array for storing PIN, pointer to entered PIN
u32 flag1=0,chances,attempts=0,pinchange=0;              // Flags and counters for login attempts & PIN change

volatile s8 uart0_rx_buf[MAX_BUF_LEN2]={0};              // UART0 receive buffer
volatile u32 uart0_rx_index = 0;                         // UART0 receive buffer index
volatile u32 uart0_rx_complete = 0;                      // UART0 receive complete flag

volatile s8 uart1_rx_buf[MAX_BUF_LEN1]={0};              // UART1 receive buffer
volatile u32 uart1_rx_index = 0;                         // UART1 receive buffer index
volatile u32 uart1_rx_complete = 0;                      // UART1 receive complete flag
volatile u32 uart1_rx_started = 0;                       // UART1 data reception started flag

u32 uart0_rx_valid=0;                                    // UART0 data valid flag

volatile unsigned int uart_checksum = 0;                 // UART checksum variable (for data validation)

// ---------------- Main Program ----------------
int main()
{
	IODIR0|=1<<LED;                                       // Configure LED pin as output
	InitKPM();                                            // Initialize Keypad
	InitLCD();                                            // Initialize LCD
	Init_UART0();                                         // Initialize UART0
	Init_UART1();                                         // Initialize UART1

	while(1)                                              // Infinite loop
	{
		CmdLCD(CLEAR_LCD);                                // Clear LCD screen
		rotate_string("WELCOME TO ASSAM ATM ",            // Display scrolling welcome message
		              strlen("WELCOME TO ASSAM ATM "),0);

		attempts=0;                                       // Reset login attempts
		pinchange=0;                                      // Reset PIN change flag

		if(validate_RFID())                               // Step 1: Validate RFID card
		{
				U1IER = 0x00;                             // Disable UART1 interrupts (safe zone)
				VICIntEnClr = (1 << 7);                   // Clear VIC interrupt enable bit for UART1

				if(validate_PIN())                        // Step 2: Validate PIN
				{
					main_MENU();                          // Step 3: Show main menu if PIN is correct
				}

				U1IER = 0x01;                             // Re-enable UART1 Receive Data Available interrupt
				VICIntEnable |= (1 << 7);                 // Re-enable VIC interrupt for UART1
		}
	}
}
