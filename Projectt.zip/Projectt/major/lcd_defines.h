#define LCD_DATA 16           // Define starting pin number for LCD data bus (D0�D7 mapped from this base)
#define LCD_RS 3              // LCD Register Select pin (0 = Command, 1 = Data)
#define LCD_RW 5              // LCD Read/Write pin (0 = Write, 1 = Read)
#define LCD_EN 4              // LCD Enable pin (used to latch data/command)

// LCD Command codes (as per HD44780 LCD controller datasheet)
#define CLEAR_LCD 0x01        // Clear display and reset cursor to home position
#define SHIFT_CUR_RIGHT 0x06  // Move cursor right after writing a character
#define DSP_OFF 0x08          // Display OFF, cursor OFF
#define DSP_ON_CUR_OFF 0x0C   // Display ON, cursor OFF
#define MODE_8BIT_2LINE 0x38  // 8-bit mode, 2-line display, 5x8 dot characters
#define GOTO_LINE1_POS0 0x80  // Set cursor to Line 1, position 0
#define GOTO_LINE2_POS0 0xC0  // Set cursor to Line 2, position 0
