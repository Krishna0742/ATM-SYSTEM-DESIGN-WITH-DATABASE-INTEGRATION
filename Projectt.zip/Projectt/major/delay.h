#include "types.h"          // Include custom type definitions (u32, s8, etc.)

void delay_s(u32 delays);   // Function prototype: delay for given seconds
void delay_ms(u32 delayms); // Function prototype: delay for given milliseconds
void delay_us(u32 delayus); // Function prototype: delay for given microseconds
