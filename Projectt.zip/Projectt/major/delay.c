#include "headers.h"   // Include user-defined header file (likely contains typedef for u32)

// Function to generate delay in microseconds
void delay_us(u32 delayus)
{
	delayus *=12;        // Adjust delay count (12 cycles per microsecond approx. for given clock)
	while(delayus--);    // Busy-wait loop until counter reaches 0
}

// Function to generate delay in milliseconds
void delay_ms(u32 delayms)
{
	delayms *=12000;     // Adjust delay count (12000 cycles per millisecond approx.)
	while(delayms--);    // Busy-wait loop until counter reaches 0
}

// Function to generate delay in seconds
void delay_s(u32 delays)
{
	delays *= 12000000;  // Adjust delay count (12,000,000 cycles per second approx.)
	while(delays--);     // Busy-wait loop until counter reaches 0
}
