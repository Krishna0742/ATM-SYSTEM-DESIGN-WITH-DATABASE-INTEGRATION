#ifndef HEADER        // If HEADER is not already defined, then define it
#define HEADER        // Define HEADER to prevent multiple inclusion of this file

#include <LPC21xx.h>  // Header file for NXP LPC21xx ARM7 microcontrollers (registers & definitions)
#include <string.h>   // Standard C library: string handling functions
#include <stdlib.h>   // Standard C library: memory allocation, conversions, etc.
#include <stdio.h>    // Standard C library: input/output functions

// User-defined headers for modular project
#include "types.h"            // Custom type definitions (likely defines u32, s8, etc.)
#include "lcd.h"              // LCD display function prototypes
#include "lcd_defines.h"      // LCD command/data macros or constants
#include "kpm.h"              // Keypad functions
#include "kpm_defines.h"      // Keypad macros/constants
#include "delay.h"            // Delay function prototypes
#include "uart.h"             // UART communication function prototypes
#include "uart_defines.h"     // UART configuration macros/constants
#include "others_functions.h" // Other helper functions
#include "bank_functions.h"   // Banking-related functions (PIN, balance, etc.)

#define LED 15          // Define LED pin number (likely connected to P0.15 or P1.15)
////#define DEBUG        // Debug mode (currently commented out)

#define MAX_BUF_LEN1 9      // Maximum buffer length for UART1 receive
#define MAX_BUF_LEN2 100    // Maximum buffer length for UART0 receive
#define TIMEOUT_FLAG 255    // Special value used to indicate timeout in communication
#define MAX_AMOUNT 30000    // Maximum transaction amount allowed

// Global variables (declared elsewhere, just referenced here with extern)
extern s8 pin[5], *givenpin;                  // PIN storage (entered PIN vs stored PIN)
extern u32 flag1, chances, attempts, pinchange;  // Flags and counters for system logic
extern s8 KPMLUT[][4];                        // Keypad Lookup Table (maps key positions to characters)
// Example: {'7','8','9','*','4','5','6','/','1','2','3','-','c','0','=','+'}
extern s8 MENU[][16];                         // Menu options stored in 2D array (each option up to 16 chars)

// UART0 receive buffer and related variables
extern volatile s8 uart0_rx_buf[MAX_BUF_LEN2];   // Buffer for UART0 incoming data
extern volatile u32 uart0_rx_index;              // Current index in UART0 buffer
extern volatile u32 uart0_rx_complete;           // Flag to indicate UART0 data reception complete

// UART1 receive buffer and related variables
extern volatile s8 uart1_rx_buf[MAX_BUF_LEN1];   // Buffer for UART1 incoming data
extern volatile u32 uart1_rx_index;              // Current index in UART1 buffer
extern volatile u32 uart1_rx_complete;           // Flag to indicate UART1 data reception complete
extern volatile u32 uart1_rx_started;            // Flag to indicate UART1 reception started
extern volatile u32 uart_checksum;               // Checksum for UART1 received data
extern u32 uart0_rx_valid;                       // Flag to indicate UART0 data is valid

#endif  // HEADER   // End of include guard
